# TAYSONX Android

Android touch automation helper with two draggable touch markers.

## Features
- Floating A/B markers.
- Simultaneous two-point gesture.
- Configurable requested interval starting at 0.01 ms.
- Finite run count, or 0 for continuous operation.
- Stop control and completed-cycle / measured-throughput display.

## Android permissions
- Display over other apps.
- Accessibility service with gesture capability.

## Timing note
0.01 ms is a requested scheduling interval, not a guaranteed physical touch rate. Android's accessibility gesture dispatcher, event loop, display, and target app determine the real achievable rate. The app displays measured completed gestures per second.

Use only on apps and interfaces you own or are authorized to test.
