# TAYSONX Android — v1.3 Royal Edition

A premium black-and-gold Android touch helper for authorized testing and accessibility workflows.

## Royal Edition visual update
- New black-and-gold interface inspired by Design A.
- Crown above the TAYSON wordmark in the main screen and floating panel.
- New crown-and-T launcher icon.
- Gold-bordered black cards, gold controls, and a matching status/navigation bar.
- Floating control rail keeps its draggable header and movable A/B markers.
- Floating controls use the same gold theme for Start/Stop, Speed, Infinite, Count, and Minimize/Restore.

## Existing controls
- A and B draggable touch markers.
- Start/stop control.
- Speed presets from `0.001 ms` through `10 ms`, plus a custom value field.
- Finite cycle count and infinite-mode toggle.
- Minimize to a movable crown bubble; tap it to restore the panel.
- Completed rounds and measured average rounds per second.
- Settings are saved locally.

## Timing note
The selected interval is a requested scheduling interval. Android's accessibility gesture dispatcher, event loop, device load, and touch subsystem determine actual timing. Values below one millisecond cannot be guaranteed as physical touch intervals; `0.001 ms` is accepted as a requested setting, not a promise of 1,000,000 taps per second.

## Permissions
- Display over other apps.
- Accessibility service with gesture capability.

The service does not inspect screen contents. Use it only on apps and interfaces you own or are authorized to test.
