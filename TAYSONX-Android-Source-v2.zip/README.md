# TAYSONX Android — v1.2

A polished Android floating touch helper for authorized testing and accessibility workflows.

## What's new in v1.2
- Luxury dark interface with emerald and champagne-gold accents.
- Compact, draggable floating side panel.
- Separate controls for start/stop, speed presets, infinite mode, cycle count, and minimize/restore.
- A and B touch markers remain independently draggable.
- Speed presets from `0.001 ms` through `10 ms`, plus a custom value field.
- Remembers the selected interval, cycle count, and infinite-mode preference.
- Minimize collapses the controls to a movable TX bubble; tapping it restores the panel without closing the service.
- Displays completed rounds and measured average rounds per second.

## Important timing note
The selected interval is a requested scheduling interval. Android's accessibility gesture dispatcher, event loop, device load, and touch subsystem determine the actual timing. Values below one millisecond cannot be guaranteed as physical touch intervals; `0.001 ms` is accepted as a requested setting, not a promise of 1,000,000 taps per second.

## Permissions
- Display over other apps.
- Accessibility service with gesture capability.

The service does not inspect screen contents. Use it only on apps and interfaces you own or are authorized to test.
