package com.taysonx.android;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class TapAccessibilityService extends AccessibilityService {
    private static TapAccessibilityService instance;

    private static final int PANEL_BG = Color.rgb(6, 6, 6);
    private static final int GOLD = Color.rgb(218, 174, 67);
    private static final int GOLD_LIGHT = Color.rgb(249, 220, 137);
    private static final int GOLD_DARK = Color.rgb(105, 78, 27);
    private static final String[] SPEED_PRESETS = {
            "0.001", "0.002", "0.005", "0.01", "0.05", "0.1", "0.5", "1", "5", "10"
    };

    private WindowManager windowManager;
    private View markerA;
    private View markerB;
    private LinearLayout panel;
    private TextView statusText;
    private TextView header;
    private Button runButton;
    private Button speedButton;
    private Button infiniteButton;
    private Button countButton;
    private View collapsedBubble;

    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams markerAParams;
    private WindowManager.LayoutParams markerBParams;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable dispatchRunnable = this::dispatchNext;

    private boolean running = false;
    private boolean infiniteMode = false;
    private int completed = 0;
    private int repetitions = 100;
    private float intervalMs = 0.01f;
    private long startedAtMs = 0L;

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // TAYSONX does not inspect screen content.
    }

    @Override
    public void onInterrupt() {
        stopSequence("تم إيقاف الخدمة");
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    public void showController() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يلزم إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            return;
        }
        if (panel != null || collapsedBubble != null) return;
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        android.content.SharedPreferences prefs =
                getSharedPreferences("taysonx_settings", MODE_PRIVATE);
        intervalMs = Math.max(0.001f, Math.min(60000f, prefs.getFloat("interval_ms", 0.01f)));
        repetitions = Math.max(1, Math.min(1000000, prefs.getInt("repetitions", 100)));
        infiniteMode = prefs.getBoolean("infinite_mode", false);

        buildPanel();
        buildMarkers();
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(6), dp(7), dp(6), dp(7));
        panel.setElevation(dp(11));

        GradientDrawable panelBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(28, 22, 11), Color.rgb(10, 10, 10), PANEL_BG});
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), GOLD);
        panel.setBackground(panelBg);

        header = new TextView(this);
        header.setText("♛\nTAYSONX");
        header.setTextColor(GOLD_LIGHT);
        header.setTypeface(Typeface.SERIF, Typeface.BOLD);
        header.setTextSize(11);
        header.setLetterSpacing(0.04f);
        header.setGravity(Gravity.CENTER);
        header.setLineSpacing(0, 0.9f);
        header.setPadding(dp(2), dp(6), dp(2), dp(6));
        header.setBackground(makeOutlined(Color.rgb(13, 13, 13), dp(10), GOLD_DARK));
        panel.addView(header, fullWidthWrap());
        makePanelDraggable(header);

        statusText = new TextView(this);
        statusText.setTextColor(GOLD_LIGHT);
        statusText.setTextSize(9);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(1), dp(7), dp(1), dp(7));
        statusText.setText("جاهز");
        panel.addView(statusText, fullWidthWrap());

        runButton = addPanelButton("▶\nابدأ", GOLD, Color.BLACK);
        runButton.setOnClickListener(v -> {
            if (running) stopSequence("أوقفه المستخدم");
            else startSequence();
        });

        speedButton = addPanelButton("⚡\nالسرعة", Color.rgb(25, 22, 16), GOLD_LIGHT);
        speedButton.setOnClickListener(v -> showSpeedDialog());

        infiniteButton = addPanelButton("∞\nلا نهائي", Color.rgb(25, 22, 16), GOLD_LIGHT);
        infiniteButton.setOnClickListener(v -> {
            if (running) {
                toast("أوقف التشغيل أولاً لتغيير وضع التكرار");
                return;
            }
            infiniteMode = !infiniteMode;
            saveSettings();
            updateControlLabels();
        });

        countButton = addPanelButton("123\nالعدد", Color.rgb(25, 22, 16), GOLD_LIGHT);
        countButton.setOnClickListener(v -> showNumberDialog(
                "عدد الجولات", String.valueOf(repetitions), false, value -> {
                    if (value < 1 || value > 1000000 || value != Math.floor(value)) {
                        toast("أدخل عدداً من 1 إلى 1000000");
                        return;
                    }
                    repetitions = (int) value;
                    saveSettings();
                    updateControlLabels();
                }));

        Button minimizeButton = addPanelButton("⌄\nإخفاء", Color.rgb(33, 27, 16), GOLD_LIGHT);
        minimizeButton.setOnClickListener(v -> collapsePanel());

        panelParams = overlayParams(dp(88), WindowManager.LayoutParams.WRAP_CONTENT);
        panelParams.gravity = Gravity.TOP | Gravity.RIGHT;
        panelParams.x = dp(7);
        panelParams.y = dp(115);
        windowManager.addView(panel, panelParams);

        updateControlLabels();
    }

    private Button addPanelButton(String text, int color, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(textColor);
        button.setTextSize(10);
        button.setTypeface(null, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(43));
        button.setPadding(dp(1), dp(3), dp(1), dp(3));
        GradientDrawable buttonBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{lighten(color, color == GOLD ? 1.12f : 1.18f), color});
        buttonBg.setCornerRadius(dp(11));
        buttonBg.setStroke(dp(1), color == GOLD ? GOLD_LIGHT : GOLD_DARK);
        button.setBackground(buttonBg);
        button.setElevation(dp(2));
        LinearLayout.LayoutParams lp = fullWidthWrap();
        lp.topMargin = dp(5);
        panel.addView(button, lp);
        return button;
    }

    private int lighten(int color, float factor) {
        return Color.rgb(
                Math.min(255, (int) (Color.red(color) * factor)),
                Math.min(255, (int) (Color.green(color) * factor)),
                Math.min(255, (int) (Color.blue(color) * factor)));
    }

    private void showSpeedDialog() {
        String[] choices = new String[SPEED_PRESETS.length + 1];
        for (int i = 0; i < SPEED_PRESETS.length; i++) {
            choices[i] = SPEED_PRESETS[i] + " ms";
        }
        choices[choices.length - 1] = "قيمة مخصصة…";

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("اختر سرعة الضغط")
                .setItems(choices, (d, which) -> {
                    if (which == SPEED_PRESETS.length) {
                        showNumberDialog("سرعة مخصصة (ms)", formatInterval(intervalMs), true, value -> {
                            if (value < 0.001 || value > 60000) {
                                toast("السرعة يجب أن تكون بين 0.001 و60000 ms");
                                return;
                            }
                            intervalMs = (float) value;
                            saveSettings();
                            updateControlLabels();
                        });
                    } else {
                        intervalMs = Float.parseFloat(SPEED_PRESETS[which]);
                        saveSettings();
                        updateControlLabels();
                    }
                })
                .setNegativeButton("إغلاق", null)
                .create();
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow != null) dialogWindow.setType(overlayType());
        dialog.show();
    }

    private String formatInterval(float value) {
        return String.format(Locale.US, "%.6f", value)
                .replaceAll("0+$", "")
                .replaceAll("\\.$", "");
    }

    private void buildMarkers() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int markerSize = dp(54);
        int centerY = Math.max(dp(120), metrics.heightPixels / 2);

        markerA = createMarker("A", GOLD);
        markerB = createMarker("B", GOLD_LIGHT);

        markerAParams = overlayParams(markerSize, markerSize);
        markerAParams.gravity = Gravity.TOP | Gravity.LEFT;
        markerAParams.x = Math.max(0, metrics.widthPixels / 3 - markerSize / 2);
        markerAParams.y = Math.max(dp(20), centerY - markerSize / 2);

        markerBParams = overlayParams(markerSize, markerSize);
        markerBParams.gravity = Gravity.TOP | Gravity.LEFT;
        markerBParams.x = Math.max(0, (metrics.widthPixels * 2) / 3 - markerSize / 2);
        markerBParams.y = Math.max(dp(20), centerY - markerSize / 2);

        makeDraggable(markerA, markerAParams);
        makeDraggable(markerB, markerBParams);
        windowManager.addView(markerA, markerAParams);
        windowManager.addView(markerB, markerBParams);
    }

    private GradientDrawable makeRounded(int color, int radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        return bg;
    }

    private GradientDrawable makeOutlined(int color, int radiusDp, int strokeColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        bg.setStroke(dp(1), strokeColor);
        return bg;
    }

    private TextView createMarker(String label, int color) {
        TextView marker = new TextView(this);
        marker.setText(label);
        marker.setTextColor(GOLD_LIGHT);
        marker.setTextSize(19);
        marker.setTypeface(null, Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.argb(235, 8, 8, 8));
        bg.setStroke(dp(3), color);
        marker.setBackground(bg);
        return marker;
    }

    private void makePanelDraggable(View dragHandle) {
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (panelParams == null) return true;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = panelParams.x;
                        startY = panelParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = Math.max(0, startX - (int) (event.getRawX() - touchX));
                        panelParams.y = Math.max(0, startY + (int) (event.getRawY() - touchY));
                        try { windowManager.updateViewLayout(panel, panelParams); }
                        catch (Exception ignored) { }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void makeDraggable(View view, WindowManager.LayoutParams params) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (running) return true;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = Math.max(0, startX + (int) (event.getRawX() - touchX));
                        params.y = Math.max(0, startY + (int) (event.getRawY() - touchY));
                        try { windowManager.updateViewLayout(view, params); }
                        catch (Exception ignored) { }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void collapsePanel() {
        if (panel == null || collapsedBubble != null) return;
        removeView(panel);

        TextView bubble = new TextView(this);
        bubble.setText("♛");
        bubble.setTextColor(GOLD_LIGHT);
        bubble.setTextSize(23);
        bubble.setTypeface(Typeface.SERIF, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(7, 7, 7));
        bg.setStroke(dp(2), GOLD);
        bubble.setBackground(bg);

        bubbleParams = overlayParams(dp(52), dp(52));
        bubbleParams.gravity = Gravity.TOP | Gravity.RIGHT;
        bubbleParams.x = dp(5);
        bubbleParams.y = panelParams != null ? panelParams.y : dp(115);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - touchX;
                        float dy = event.getRawY() - touchY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            bubbleParams.x = Math.max(0, startX - (int) dx);
                            bubbleParams.y = Math.max(0, startY + (int) dy);
                            try { windowManager.updateViewLayout(collapsedBubble, bubbleParams); }
                            catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) expandPanel();
                        return true;
                    default:
                        return true;
                }
            }
        });

        collapsedBubble = bubble;
        windowManager.addView(collapsedBubble, bubbleParams);
    }

    private void expandPanel() {
        if (collapsedBubble == null || panel == null) return;
        removeView(collapsedBubble);
        collapsedBubble = null;
        windowManager.addView(panel, panelParams);
        updateControlLabels();
    }

    private void showNumberDialog(String title, String initial, boolean decimal,
                                  NumberCallback callback) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(initial);
        input.setSelectAllOnFocus(true);
        input.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_NUMBER);
        input.setTextSize(18);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));

        LinearLayout holder = new LinearLayout(this);
        holder.setPadding(dp(20), dp(8), dp(20), dp(4));
        holder.addView(input, fullWidthWrap());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(holder)
                .setPositiveButton("حفظ", null)
                .setNegativeButton("إلغاء", null)
                .create();

        Window dialogWindow = dialog.getWindow();
        if (dialogWindow != null) {
            dialogWindow.setType(overlayType());
            dialogWindow.setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                            | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        dialog.setOnShowListener(ignored -> {
            Button save = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            save.setOnClickListener(v -> {
                try {
                    double value = Double.parseDouble(input.getText().toString().trim());
                    callback.onValue(value);
                    dialog.dismiss();
                } catch (Exception e) {
                    toast("تحقق من القيمة المدخلة");
                }
            });
            input.requestFocus();
        });
        dialog.show();
    }

    private interface NumberCallback {
        void onValue(double value);
    }

    private void startSequence() {
        if (markerA == null || markerB == null) return;
        android.content.SharedPreferences prefs =
                getSharedPreferences("taysonx_settings", MODE_PRIVATE);
        infiniteMode = prefs.getBoolean("infinite_mode", infiniteMode);
        repetitions = Math.max(1, prefs.getInt("repetitions", repetitions));
        intervalMs = Math.max(0.001f, prefs.getFloat("interval_ms", intervalMs));

        completed = 0;
        startedAtMs = SystemClock.elapsedRealtime();
        running = true;
        setMarkersTouchable(false);
        runButton.setText("■\nإيقاف");
        updateStatus("يعمل الآن");
        dispatchNext();
    }

    private void dispatchNext() {
        if (!running) return;

        float[] a = markerCenter(markerA);
        float[] b = markerCenter(markerB);

        Path pathA = new Path();
        pathA.moveTo(a[0], a[1]);
        pathA.lineTo(a[0], a[1]);
        Path pathB = new Path();
        pathB.moveTo(b[0], b[1]);
        pathB.lineTo(b[0], b[1]);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(pathA, 0, 1))
                .addStroke(new GestureDescription.StrokeDescription(pathB, 0, 1))
                .build();

        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription completedGesture) {
                if (!running) return;
                completed++;
                long elapsed = Math.max(1L, SystemClock.elapsedRealtime() - startedAtMs);
                double rate = completed * 1000.0 / elapsed;
                String total = infiniteMode ? "∞" : String.valueOf(repetitions);
                updateStatus("الجولات " + completed + "/" + total
                        + " • " + String.format(java.util.Locale.US, "%.1f", rate) + "/ث");

                if (!infiniteMode && completed >= repetitions) {
                    stopSequence("اكتمل العدد المحدد");
                    return;
                }
                scheduleNext();
            }

            @Override
            public void onCancelled(GestureDescription cancelledGesture) {
                stopSequence("ألغى النظام الإيماءة");
            }
        }, handler);

        if (!accepted) stopSequence("رفض النظام الإيماءة");
    }

    private void scheduleNext() {
        if (!running) return;
        if (intervalMs < 1.0f) {
            handler.post(dispatchRunnable);
        } else {
            handler.postDelayed(dispatchRunnable, Math.max(1L, (long) Math.ceil(intervalMs)));
        }
    }

    private float[] markerCenter(View marker) {
        int[] location = new int[2];
        marker.getLocationOnScreen(location);
        return new float[] {
                location[0] + marker.getWidth() / 2f,
                location[1] + marker.getHeight() / 2f
        };
    }

    private void stopSequence(String reason) {
        if (!running) return;
        running = false;
        handler.removeCallbacks(dispatchRunnable);
        setMarkersTouchable(true);
        if (runButton != null) runButton.setText("▶\nابدأ");
        updateStatus(reason + " • الإجمالي " + completed);
    }

    private void setMarkersTouchable(boolean touchable) {
        updateMarkerTouchFlag(markerA, markerAParams, touchable);
        updateMarkerTouchFlag(markerB, markerBParams, touchable);
    }

    private void updateMarkerTouchFlag(View marker, WindowManager.LayoutParams params, boolean touchable) {
        if (marker == null || params == null || windowManager == null) return;
        if (touchable) params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { windowManager.updateViewLayout(marker, params); }
        catch (Exception ignored) { }
    }

    private void updateControlLabels() {
        if (speedButton != null) speedButton.setText("⚡\n" + formatInterval(intervalMs) + "ms");
        if (infiniteButton != null) {
            infiniteButton.setText(infiniteMode ? "∞\nمفعّل" : "∞\nلا نهائي");
        }
        if (countButton != null) {
            countButton.setText("123\n" + repetitions);
            countButton.setEnabled(!infiniteMode);
            countButton.setAlpha(infiniteMode ? 0.5f : 1f);
        }
    }

    private void saveSettings() {
        getSharedPreferences("taysonx_settings", MODE_PRIVATE).edit()
                .putFloat("interval_ms", intervalMs)
                .putInt("repetitions", repetitions)
                .putBoolean("infinite_mode", infiniteMode)
                .apply();
    }

    private void updateStatus(String text) {
        if (statusText != null) statusText.setText(text);
    }

    private void hideController() {
        stopSequence("تم إيقاف الخدمة");
        removeView(markerA);
        removeView(markerB);
        removeView(panel);
        removeView(collapsedBubble);
        markerA = null;
        markerB = null;
        panel = null;
        collapsedBubble = null;
        statusText = null;
        runButton = null;
        speedButton = null;
        infiniteButton = null;
        countButton = null;
        header = null;
    }

    private void removeView(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); }
        catch (Exception ignored) { }
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        return new WindowManager.LayoutParams(
                width, height,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
    }

    private LinearLayout.LayoutParams fullWidthWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        hideController();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
