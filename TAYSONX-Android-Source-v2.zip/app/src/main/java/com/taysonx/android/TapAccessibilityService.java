package com.taysonx.android;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class TapAccessibilityService extends AccessibilityService {
    private static TapAccessibilityService instance;

    private WindowManager windowManager;
    private View markerA;
    private View markerB;
    private LinearLayout panel;
    private TextView statusText;
    private Button runButton;
    private WindowManager.LayoutParams markerAParams;
    private WindowManager.LayoutParams markerBParams;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean running = false;
    private int completed = 0;
    private int repetitions = 100; // 0 means continuous
    private float intervalMs = 0.01f;
    private long startedAtMs = 0L;

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // The service does not inspect screen content.
    }

    @Override
    public void onInterrupt() {
        stopSequence("تم إيقاف الخدمة");
    }

    public void showController() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يلزم إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            return;
        }
        if (panel != null) return;
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        android.content.SharedPreferences prefs =
                getSharedPreferences("taysonx_settings", MODE_PRIVATE);
        intervalMs = Math.max(0.01f, Math.min(60000f, prefs.getFloat("interval_ms", 0.01f)));
        repetitions = Math.max(0, Math.min(1000000, prefs.getInt("repetitions", 100)));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(9), dp(6), dp(9), dp(6));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.argb(242, 20, 28, 38));
        panelBg.setCornerRadius(dp(15));
        panelBg.setStroke(dp(1), Color.rgb(0, 220, 110));
        panel.setBackground(panelBg);

        TextView brand = new TextView(this);
        brand.setText("TAYSONX");
        brand.setTextColor(Color.WHITE);
        brand.setTypeface(null, Typeface.BOLD);
        brand.setTextSize(14);
        brand.setGravity(Gravity.CENTER);
        panel.addView(brand);

        statusText = new TextView(this);
        statusText.setText("الفاصل المطلوب: " + intervalMs + "ms | جاهز");
        statusText.setTextColor(Color.rgb(170, 255, 200));
        statusText.setTextSize(11);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(3), dp(4), dp(3), dp(4));
        panel.addView(statusText);

        runButton = new Button(this);
        runButton.setText("بدء الضغط المزدوج");
        runButton.setTextSize(12);
        runButton.setAllCaps(false);
        runButton.setOnClickListener(v -> {
            if (running) stopSequence("أوقفه المستخدم");
            else startSequence();
        });
        panel.addView(runButton);

        Button hideButton = new Button(this);
        hideButton.setText("إخفاء اللوحة");
        hideButton.setTextSize(12);
        hideButton.setAllCaps(false);
        hideButton.setOnClickListener(v -> hideController());
        panel.addView(hideButton);

        WindowManager.LayoutParams panelParams = overlayParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = dp(60);
        windowManager.addView(panel, panelParams);

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int markerSize = dp(54);
        int centerY = Math.max(dp(120), metrics.heightPixels / 2);

        markerA = createMarker("A", Color.rgb(0, 145, 255));
        markerB = createMarker("B", Color.rgb(255, 125, 0));

        markerAParams = overlayParams(markerSize, markerSize);
        markerAParams.gravity = Gravity.TOP | Gravity.START;
        markerAParams.x = Math.max(0, metrics.widthPixels / 3 - markerSize / 2);
        markerAParams.y = Math.max(dp(20), centerY - markerSize / 2);

        markerBParams = overlayParams(markerSize, markerSize);
        markerBParams.gravity = Gravity.TOP | Gravity.START;
        markerBParams.x = Math.max(0, (metrics.widthPixels * 2) / 3 - markerSize / 2);
        markerBParams.y = Math.max(dp(20), centerY - markerSize / 2);

        makeDraggable(markerA, markerAParams);
        makeDraggable(markerB, markerBParams);
        windowManager.addView(markerA, markerAParams);
        windowManager.addView(markerB, markerBParams);
    }

    private TextView createMarker(String label, int color) {
        TextView marker = new TextView(this);
        marker.setText(label);
        marker.setTextColor(Color.WHITE);
        marker.setTextSize(19);
        marker.setTypeface(null, Typeface.BOLD);
        marker.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.argb(205, Color.red(color), Color.green(color), Color.blue(color)));
        bg.setStroke(dp(3), Color.WHITE);
        marker.setBackground(bg);
        return marker;
    }

    private void makeDraggable(View view, WindowManager.LayoutParams params) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (running) return true;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = Math.max(0, startX + (int) (event.getRawX() - touchX));
                        params.y = Math.max(0, startY + (int) (event.getRawY() - touchY));
                        try { windowManager.updateViewLayout(view, params); }
                        catch (Exception ignored) { }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void startSequence() {
        if (markerA == null || markerB == null) return;
        completed = 0;
        startedAtMs = SystemClock.elapsedRealtime();
        running = true;
        setMarkersTouchable(false);
        runButton.setText("إيقاف فوراً");
        updateStatus("يبدأ... الفاصل المطلوب " + intervalMs + "ms");
        dispatchNext();
    }

    private void dispatchNext() {
        if (!running) return;

        float[] a = markerCenter(markerA);
        float[] b = markerCenter(markerB);

        Path pathA = new Path();
        pathA.moveTo(a[0], a[1]);
        pathA.lineTo(a[0], a[1]);
        Path pathB = new Path();
        pathB.moveTo(b[0], b[1]);
        pathB.lineTo(b[0], b[1]);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(pathA, 0, 1))
                .addStroke(new GestureDescription.StrokeDescription(pathB, 0, 1))
                .build();

        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription completedGesture) {
                if (!running) return;
                completed++;
                long elapsed = Math.max(1L, SystemClock.elapsedRealtime() - startedAtMs);
                double rate = completed * 1000.0 / elapsed;
                updateStatus("الجولات: " + completed +
                        (repetitions == 0 ? " / ∞" : " / " + repetitions) +
                        " | المعدل: " + String.format(java.util.Locale.US, "%.1f", rate) + "/ث");
                if (repetitions > 0 && completed >= repetitions) {
                    stopSequence("اكتمل العدد المحدد");
                    return;
                }
                scheduleNext();
            }

            @Override
            public void onCancelled(GestureDescription cancelledGesture) {
                stopSequence("ألغى النظام الإيماءة");
            }
        }, handler);

        if (!accepted) stopSequence("رفض النظام الإيماءة");
    }

    private void scheduleNext() {
        if (!running) return;
        // Android's callback and touch dispatcher set the real lower bound.
        // Sub-millisecond values are treated as "dispatch again immediately".
        if (intervalMs < 1.0f) {
            handler.post(this::dispatchNext);
        } else {
            handler.postDelayed(this::dispatchNext, Math.max(1L, (long) Math.ceil(intervalMs)));
        }
    }

    private float[] markerCenter(View marker) {
        int[] location = new int[2];
        marker.getLocationOnScreen(location);
        return new float[] {
                location[0] + marker.getWidth() / 2f,
                location[1] + marker.getHeight() / 2f
        };
    }

    private void stopSequence(String reason) {
        if (!running) return;
        running = false;
        handler.removeCallbacksAndMessages(null);
        setMarkersTouchable(true);
        if (runButton != null) runButton.setText("بدء الضغط المزدوج");
        updateStatus(reason + " | الإجمالي: " + completed);
    }

    private void setMarkersTouchable(boolean touchable) {
        updateMarkerTouchFlag(markerA, markerAParams, touchable);
        updateMarkerTouchFlag(markerB, markerBParams, touchable);
    }

    private void updateMarkerTouchFlag(View marker, WindowManager.LayoutParams params, boolean touchable) {
        if (marker == null || params == null || windowManager == null) return;
        if (touchable) params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { windowManager.updateViewLayout(marker, params); }
        catch (Exception ignored) { }
    }

    private void hideController() {
        if (running) stopSequence("تم إخفاء اللوحة");
        removeView(markerA);
        removeView(markerB);
        removeView(panel);
        markerA = null;
        markerB = null;
        panel = null;
        statusText = null;
        runButton = null;
    }

    private void removeView(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); }
        catch (Exception ignored) { }
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        return new WindowManager.LayoutParams(
                width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
    }

    private void updateStatus(String text) {
        if (statusText != null) statusText.setText(text);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        hideController();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
