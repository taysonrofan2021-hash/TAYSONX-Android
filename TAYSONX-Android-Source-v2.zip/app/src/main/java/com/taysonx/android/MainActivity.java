package com.taysonx.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 12, 17);
    private static final int CARD = Color.rgb(17, 27, 34);
    private static final int CARD_LIGHT = Color.rgb(25, 38, 45);
    private static final int EMERALD = Color.rgb(0, 205, 133);
    private static final int GOLD = Color.rgb(222, 183, 104);
    private static final int TEXT = Color.rgb(242, 246, 244);
    private static final int MUTED = Color.rgb(157, 174, 176);
    private static final String[] SPEED_PRESETS = {
            "0.001", "0.002", "0.005", "0.01", "0.05", "0.1", "0.5", "1", "5", "10"
    };

    private EditText speedInput;
    private EditText countInput;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        android.content.SharedPreferences saved = getSharedPreferences("taysonx_settings", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        buildHero(root);
        buildSpeedCard(root, saved);
        buildCountCard(root, saved);
        buildSetupCard(root);
        buildLaunchCard(root);

        setContentView(scroll);
    }

    private void buildHero(LinearLayout root) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(22), dp(22), dp(22));
        hero.setBackground(gradient(
                new int[]{Color.rgb(24, 49, 49), Color.rgb(12, 22, 29)},
                dp(24), GOLD));
        hero.setElevation(dp(4));
        root.addView(hero, matchWrap());

        TextView eyebrow = new TextView(this);
        eyebrow.setText("T A Y S O N X     /     TOUCH CONTROL");
        eyebrow.setTextColor(GOLD);
        eyebrow.setTextSize(10);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setGravity(Gravity.CENTER);
        hero.addView(eyebrow, matchWrap());

        TextView title = new TextView(this);
        title.setText("TAYSONX");
        title.setTextColor(TEXT);
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(2));
        hero.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("تحكّم أنيق ودقيق في اللمس المزدوج");
        subtitle.setTextColor(Color.rgb(186, 207, 199));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        hero.addView(subtitle, matchWrap());

        TextView badge = new TextView(this);
        badge.setText("  PRO  •  الإصدار 1.2  ");
        badge.setTextColor(EMERALD);
        badge.setTextSize(11);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        badge.setPadding(dp(12), dp(7), dp(12), dp(7));
        badge.setBackground(rounded(Color.rgb(14, 47, 42), dp(30), Color.rgb(35, 112, 88)));
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        badgeLp.gravity = Gravity.CENTER;
        badgeLp.topMargin = dp(15);
        hero.addView(badge, badgeLp);
    }

    private void buildSpeedCard(LinearLayout root, android.content.SharedPreferences saved) {
        LinearLayout card = createCard(root);
        addSectionTitle(card, "سرعة الضغط", "حدد الفاصل المطلوب بين جولات اللمس بالمللي ثانية.");

        speedInput = addInput(card,
                formatSpeed(saved.getFloat("interval_ms", 0.01f)), true,
                "مثال: 0.001");

        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.setPadding(0, dp(8), 0, dp(3));
        for (String value : SPEED_PRESETS) {
            TextView chip = new TextView(this);
            chip.setText(value + " ms");
            chip.setTextColor(value.equals("0.01") ? GOLD : TEXT);
            chip.setTextSize(11);
            chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(12), dp(10), dp(12), dp(10));
            chip.setBackground(rounded(
                    value.equals("0.01") ? Color.rgb(48, 43, 31) : CARD_LIGHT,
                    dp(18), value.equals("0.01") ? GOLD : Color.rgb(52, 74, 76)));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(39));
            chipLp.setMargins(0, 0, dp(7), 0);
            presets.addView(chip, chipLp);
            chip.setOnClickListener(v -> speedInput.setText(value));
        }
        horizontal.addView(presets, new HorizontalScrollView.LayoutParams(
                HorizontalScrollView.LayoutParams.WRAP_CONTENT,
                HorizontalScrollView.LayoutParams.WRAP_CONTENT));
        card.addView(horizontal, matchWrap());

        TextView note = new TextView(this);
        note.setText("الحد الأدنى 0.001 ms — هذه قيمة جدولة مطلوبة وليست ضماناً لسرعة لمس فعلية.");
        note.setTextColor(GOLD);
        note.setTextSize(11);
        note.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams noteLp = matchWrap();
        noteLp.topMargin = dp(7);
        card.addView(note, noteLp);
    }

    private void buildCountCard(LinearLayout root, android.content.SharedPreferences saved) {
        LinearLayout card = createCard(root);
        addSectionTitle(card, "عدد الجولات", "حدد عدد مرات تنفيذ اللمس. ويمكنك تفعيل التكرار اللانهائي من الشريط العائم.");
        countInput = addInput(card,
                String.valueOf(saved.getInt("repetitions", 100)), false,
                "عدد الجولات — من 1 إلى 1,000,000");
    }

    private void buildSetupCard(LinearLayout root) {
        LinearLayout card = createCard(root);
        addSectionTitle(card, "إعداد التطبيق", "فعّل الأذونات المطلوبة مرة واحدة فقط.");

        Button overlayButton = addActionButton(card, "01   السماح بالظهور فوق التطبيقات", CARD_LIGHT, TEXT);
        overlayButton.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                toast("إذن الظهور فوق التطبيقات مفعّل بالفعل");
            }
        });

        Button accessibilityButton = addActionButton(card, "02   تفعيل خدمة TAYSONX", CARD_LIGHT, TEXT);
        accessibilityButton.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    }

    private void buildLaunchCard(LinearLayout root) {
        LinearLayout card = createCard(root);
        card.setBackground(gradient(
                new int[]{Color.rgb(19, 43, 39), Color.rgb(14, 26, 32)},
                dp(21), Color.rgb(42, 104, 83)));

        TextView heading = new TextView(this);
        heading.setText("جاهز للانطلاق؟");
        heading.setTextColor(TEXT);
        heading.setTextSize(17);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(heading, matchWrap());

        TextView body = new TextView(this);
        body.setText("بعد التشغيل يمكنك تحريك علامتي A وB، وسحب لوحة التحكم إلى أي مكان على الشاشة.");
        body.setTextColor(MUTED);
        body.setTextSize(12);
        body.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams bodyLp = matchWrap();
        bodyLp.topMargin = dp(5);
        bodyLp.bottomMargin = dp(13);
        card.addView(body, bodyLp);

        Button launchButton = addActionButton(card, "▶   تشغيل لوحة TAYSONX", EMERALD, Color.rgb(5, 23, 19));
        launchButton.setTextSize(15);
        launchButton.setMinHeight(dp(54));
        launchButton.setOnClickListener(v -> startController());
    }

    private LinearLayout createCard(LinearLayout root) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(16), dp(17), dp(16));
        card.setBackground(rounded(CARD, dp(20), Color.rgb(38, 57, 62)));
        card.setElevation(dp(2));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(14);
        root.addView(card, lp);
        return card;
    }

    private void addSectionTitle(LinearLayout parent, String titleText, String description) {
        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(TEXT);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        parent.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText(description);
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(12);
        subtitle.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(4);
        parent.addView(subtitle, lp);
    }

    private EditText addInput(LinearLayout parent, String initial, boolean decimal, String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(initial);
        input.setHint(hint);
        input.setHintTextColor(Color.rgb(105, 125, 128));
        input.setTextColor(TEXT);
        input.setTextSize(16);
        input.setSelectAllOnFocus(true);
        input.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_NUMBER);
        input.setPadding(dp(14), dp(10), dp(14), dp(10));
        input.setBackground(rounded(Color.rgb(9, 16, 21), dp(13), Color.rgb(54, 82, 82)));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(12);
        parent.addView(input, lp);
        return input;
    }

    private Button addActionButton(LinearLayout parent, String label, int fill, int textColor) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(textColor);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(48));
        button.setPadding(dp(12), dp(7), dp(12), dp(7));
        button.setBackground(rounded(fill, dp(14), fill == EMERALD ? GOLD : Color.rgb(59, 81, 84)));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(9);
        parent.addView(button, lp);
        return button;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private GradientDrawable gradient(int[] colors, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private void startController() {
        if (!Settings.canDrawOverlays(this)) {
            toast("امنح إذن الظهور فوق التطبيقات أولاً");
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }

        TapAccessibilityService service = TapAccessibilityService.getInstance();
        if (service == null) {
            toast("فعّل خدمة TAYSONX من إعدادات إمكانية الوصول ثم ارجع");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        float interval;
        int count;
        try {
            interval = Float.parseFloat(speedInput.getText().toString().trim());
            if (Float.isNaN(interval) || Float.isInfinite(interval)
                    || interval < 0.001f || interval > 60000f) {
                throw new NumberFormatException();
            }
        } catch (Exception e) {
            toast("أدخل سرعة من 0.001 إلى 60000 ms");
            return;
        }

        try {
            count = Integer.parseInt(countInput.getText().toString().trim());
            if (count < 1 || count > 1000000) throw new NumberFormatException();
        } catch (Exception e) {
            toast("عدد الجولات يجب أن يكون بين 1 و1000000");
            return;
        }

        getSharedPreferences("taysonx_settings", MODE_PRIVATE).edit()
                .putFloat("interval_ms", interval)
                .putInt("repetitions", count)
                .apply();

        service.showController();
        toast("حرّك A وB إلى موضعي اللمس ثم استخدم الشريط العائم");
        finish();
    }

    private String formatSpeed(float value) {
        return String.format(Locale.US, "%.6f", value)
                .replaceAll("0+$", "")
                .replaceAll("\\.$", "");
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
