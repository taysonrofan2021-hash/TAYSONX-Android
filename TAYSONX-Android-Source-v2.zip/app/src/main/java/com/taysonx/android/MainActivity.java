package com.taysonx.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText speedInput;
    private EditText countInput;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(16, 24, 32));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("TAYSONX");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setTypeface(null, 1);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("لوحة لمس مزدوج للأندرويد");
        subtitle.setTextColor(Color.rgb(0, 230, 118));
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(7), 0, dp(22));
        root.addView(subtitle, matchWrap());

        addText(root, "السرعة", 20, Color.WHITE, true);
        addText(root, "الفاصل المطلوب بين جولات اللمس بالمللي ثانية. يمكنك إدخال قيمة تبدأ من 0.01ms.", 14, Color.LTGRAY, false);
        speedInput = addInput(root, "0.01", true);

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        String[] values = {"0.01", "0.05", "0.1", "0.5", "1", "5", "10"};
        for (String value : values) {
            Button b = new Button(this);
            b.setText(value);
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setPadding(dp(2), 0, dp(2), 0);
            b.setOnClickListener(v -> speedInput.setText(value));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1);
            lp.setMargins(dp(2), dp(4), dp(2), dp(4));
            presets.addView(b, lp);
        }
        root.addView(presets, matchWrap());

        addText(root, "عدد الجولات", 20, Color.WHITE, true);
        addText(root, "اكتب 0 للتكرار المستمر حتى تضغط إيقاف.", 14, Color.LTGRAY, false);
        countInput = addInput(root, "100", false);

        addText(root, "التجهيز", 20, Color.WHITE, true);
        Button overlayButton = addButton(root, "1 - السماح بالظهور فوق التطبيقات");
        overlayButton.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else toast("الإذن مفعّل بالفعل");
        });

        Button accessibilityButton = addButton(root, "2 - تفعيل خدمة TAYSONX");
        accessibilityButton.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button launchButton = addButton(root, "3 - تشغيل لوحة TAYSONX");
        launchButton.setOnClickListener(v -> startController());

        TextView note = new TextView(this);
        note.setText("ملاحظة تقنية: 0.01ms هي قيمة الفاصل المطلوبة فقط وليست ضماناً لسرعة لمس فعلية بهذا المقدار. أندرويد يحدد مدة الإيماءة وجدولتها، وقد يكون التنفيذ أبطأ بكثير. يعرض التطبيق عدد الجولات ومعدل التنفيذ المقاس. استخدم الأتمتة فقط على واجهات تملكها أو لديك إذن باختبارها.");
        note.setTextColor(Color.rgb(255, 213, 79));
        note.setTextSize(13);
        note.setPadding(0, dp(22), 0, 0);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private void startController() {
        if (!Settings.canDrawOverlays(this)) {
            toast("امنح إذن الظهور فوق التطبيقات أولاً");
            return;
        }
        TapAccessibilityService service = TapAccessibilityService.getInstance();
        if (service == null) {
            toast("فعّل خدمة TAYSONX من إعدادات إمكانية الوصول ثم ارجع");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        float interval;
        int count;
        try {
            interval = Float.parseFloat(speedInput.getText().toString().trim());
            if (Float.isNaN(interval) || Float.isInfinite(interval) || interval < 0.01f || interval > 60000f) {
                throw new NumberFormatException();
            }
        } catch (Exception e) {
            toast("أدخل سرعة من 0.01 إلى 60000 ms");
            return;
        }
        try {
            count = Integer.parseInt(countInput.getText().toString().trim());
            if (count < 0 || count > 1000000) throw new NumberFormatException();
        } catch (Exception e) {
            toast("عدد الجولات يجب أن يكون بين 0 و1000000");
            return;
        }

        getSharedPreferences("taysonx_settings", MODE_PRIVATE).edit()
                .putFloat("interval_ms", interval)
                .putInt("repetitions", count)
                .apply();

        service.showController();
        toast("حرّك A وB إلى موضعي اللمس ثم اضغط تشغيل");
        finish();
    }

    private EditText addInput(LinearLayout root, String initial, boolean decimal) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(initial);
        input.setTextColor(Color.WHITE);
        input.setTextSize(18);
        input.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                : InputType.TYPE_CLASS_NUMBER);
        input.setPadding(dp(14), dp(8), dp(14), dp(8));
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 200, 83)));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(7);
        lp.bottomMargin = dp(8);
        root.addView(input, lp);
        return input;
    }

    private void addText(LinearLayout root, String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(null, 1);
        view.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(9);
        lp.bottomMargin = dp(5);
        root.addView(view, lp);
    }

    private Button addButton(LinearLayout root, String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 160, 70)));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(7);
        root.addView(button, lp);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
