# TAYSONX Android — v1.1

Floating Android touch helper with:
- A and B draggable touch markers.
- A narrow floating side panel, draggable from its header.
- Start/stop control.
- Speed setting dialog (requested interval; Android does not guarantee sub-millisecond dispatch).
- Finite cycle count setting.
- Infinite mode toggle.
- Minimize to a movable TX bubble and restore by tapping the bubble.
- Measured completed gesture rate.

Permissions:
- Display over other apps.
- Accessibility service with gesture capability.

Timing note: values such as 0.01 ms are requested scheduling intervals, not guaranteed physical touch rates. Android's accessibility gesture dispatcher and event loop determine actual throughput. Use only for authorized testing and accessibility workflows.
